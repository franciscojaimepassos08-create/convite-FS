const WEDDING = {
  date: '2026-12-24T09:00:00',
  whatsapp: '258842820764', // confirmar/alterar para o número que receberá as confirmações
  mapUrl: 'https://www.google.com/maps/search/?api=1&query=Sala+Magna+Universidade+Lurio+Nampula+Mocambique',
  musicUrl: 'music.mp3'
};
const $ = id => document.getElementById(id);
const dateObj = new Date(WEDDING.date);
const dateText = date => new Intl.DateTimeFormat('pt-PT',{day:'numeric',month:'long',year:'numeric'}).format(date);
$('hero-date').textContent = dateText(dateObj);
$('month').textContent = new Intl.DateTimeFormat('pt-PT',{month:'long'}).format(dateObj).toUpperCase();
$('day').textContent = String(dateObj.getDate()).padStart(2,'0');
$('weekday').textContent = new Intl.DateTimeFormat('pt-PT',{weekday:'long'}).format(dateObj).toUpperCase();
$('year').textContent = dateObj.getFullYear();
$('map-link').href = WEDDING.mapUrl;
function countdown(){
  const diff = dateObj.getTime() - Date.now();
  if(diff <= 0){ ['days','hours','minutes','seconds'].forEach(id => $(id).textContent='0'); return; }
  $('days').textContent = Math.floor(diff/86400000);
  $('hours').textContent = String(Math.floor(diff/3600000)%24).padStart(2,'0');
  $('minutes').textContent = String(Math.floor(diff/60000)%60).padStart(2,'0');
  $('seconds').textContent = String(Math.floor(diff/1000)%60).padStart(2,'0');
}
countdown(); setInterval(countdown,1000);
$('open-invite').addEventListener('click',()=>{ $('convite').scrollIntoView({behavior:'smooth'}); startMusic(); });
if('IntersectionObserver' in window){
 const observer = new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target)}}),{threshold:.1});
 document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));
}else document.querySelectorAll('.reveal').forEach(el=>el.classList.add('visible'));

const audio = $('background-music'), musicButton = $('music-button');
audio.src = WEDDING.musicUrl;
async function startMusic(){ try { await audio.play(); musicButton.textContent='Ⅱ'; musicButton.classList.add('playing'); } catch(e) { musicButton.textContent='♫'; } }
musicButton.addEventListener('click',async()=>{ if(audio.paused) await startMusic(); else { audio.pause(); musicButton.textContent='♫'; musicButton.classList.remove('playing'); } });

$('rsvp-form').addEventListener('submit',event=>{
 event.preventDefault();
 const name = $('guest-name').value.trim(), phone = $('guest-phone').value.trim(), attendance = $('attendance').value;
 const message = `Olá! Aqui é ${name}. O meu contacto de WhatsApp é ${phone}. ${attendance}. Estou a responder ao convite de casamento de Silvina Saide Travessa e Francisco Jaime Francisco Passos, marcado para 24 de dezembro de 2026.`;
 window.open(`https://wa.me/${WEDDING.whatsapp}?text=${encodeURIComponent(message)}`,'_blank','noopener');
});

const STORAGE_KEY='silvina-francisco-convite-v2';
const panel=$('customizer'), backdrop=$('panel-backdrop');
function openPanel(){panel.classList.add('open');panel.setAttribute('aria-hidden','false');backdrop.classList.add('visible')}
function closePanel(){panel.classList.remove('open');panel.setAttribute('aria-hidden','true');backdrop.classList.remove('visible')}
$('customize-toggle').addEventListener('click',openPanel);$('close-customizer').addEventListener('click',closePanel);backdrop.addEventListener('click',closePanel);
let selectedHero='',selectedDetails='';
function readImage(file,callback){if(!file)return;if(!file.type.startsWith('image/')){alert('Escolhe um ficheiro de imagem.');return}const reader=new FileReader();reader.onload=()=>callback(reader.result);reader.readAsDataURL(file)}
$('hero-photo').addEventListener('change',e=>readImage(e.target.files[0],data=>{selectedHero=data;$('hero-preview').style.backgroundImage=`url("${data}")`;$('hero-preview').textContent=''}));
$('details-photo').addEventListener('change',e=>readImage(e.target.files[0],data=>{selectedDetails=data;$('details-preview').style.backgroundImage=`url("${data}")`;$('details-preview').textContent=''}));
$('overlay-strength').addEventListener('input',e=>{$('overlay-value').textContent=`${e.target.value}%`;document.documentElement.style.setProperty('--overlay',Number(e.target.value)/100)});
function themeChange(theme){const root=document.documentElement;const themes={classic:['#f5eee2','#fffdf8','#49372c','#654b3b','#3e2c23','#b5965d','#e9dece'],warm:['#f0e4d2','#fffaf1','#4b3326','#704b35','#39251b','#a98248','#e5d3bc'],light:['#faf6ed','#fffefa','#514337','#6a5544','#4a392d','#c0a36b','#f1eadf']};const v=themes[theme]||themes.classic;['--paper','--white','--ink','--brown','--deep','--gold','--soft'].forEach((k,i)=>root.style.setProperty(k,v[i]));}
function applySettings(settings){if(!settings)return;if(settings.hero){selectedHero=settings.hero;document.querySelector('.hero').style.backgroundImage=`linear-gradient(120deg,rgba(44,29,21,var(--overlay)),rgba(65,43,30,calc(var(--overlay)*.55))),url("${settings.hero}") center/cover`;$('hero-preview').style.backgroundImage=`url("${settings.hero}")`;$('hero-preview').textContent=''}if(settings.details){selectedDetails=settings.details;$('grande-dia').style.backgroundImage=`url("${settings.details}")`;$('details-preview').style.backgroundImage=`url("${settings.details}")`;$('details-preview').textContent=''}if(settings.theme){$('theme-choice').value=settings.theme;themeChange(settings.theme)}if(settings.overlay){$('overlay-strength').value=settings.overlay;$('overlay-value').textContent=`${settings.overlay}%`;document.documentElement.style.setProperty('--overlay',Number(settings.overlay)/100)}}
$('theme-choice').addEventListener('change',e=>themeChange(e.target.value));
$('save-customization').addEventListener('click',()=>{const settings={hero:selectedHero,details:selectedDetails,theme:$('theme-choice').value,overlay:$('overlay-strength').value};try{localStorage.setItem(STORAGE_KEY,JSON.stringify(settings));applySettings(settings);alert('Personalização guardada neste navegador.')}catch(err){alert('Não foi possível guardar. Experimenta imagens mais pequenas.')}});
$('reset-customization').addEventListener('click',()=>{localStorage.removeItem(STORAGE_KEY);selectedHero='';selectedDetails='';$('hero-photo').value='';$('details-photo').value='';$('hero-preview').style.backgroundImage='';$('details-preview').style.backgroundImage='';$('hero-preview').textContent='Pré-visualização da capa';$('details-preview').textContent='Pré-visualização';themeChange('classic');$('theme-choice').value='classic';$('overlay-strength').value=55;$('overlay-value').textContent='55%';document.documentElement.style.setProperty('--overlay',.55);document.querySelector('.hero').style.backgroundImage="linear-gradient(120deg,rgba(44,29,21,var(--overlay)),rgba(65,43,30,calc(var(--overlay)*.55))),url('https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1800&q=85') center/cover";$('grande-dia').style.backgroundImage='';alert('Visual original reposto.')});
try{const saved=localStorage.getItem(STORAGE_KEY);if(saved)applySettings(JSON.parse(saved))}catch(e){console.warn('Não foi possível recuperar a personalização.',e)}
