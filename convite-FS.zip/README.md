# Convite digital — Silvina & Francisco

Convite responsivo em HTML, CSS e JavaScript, preparado para publicação na Vercel.

## Conteúdo incluído
- Capa com botão para abrir o convite.
- Mensagem de boas-vindas e versículo bíblico.
- Contagem decrescente para 24 de dezembro de 2026.
- Palavras do noivo e da noiva.
- Bênção e identificação dos pais.
- Programa: cerimónia civil às 09h00; passeata e fotografias entre as 11h00 e as 13h00; copo de água às 17h00.
- Localização da Sala Magna da Universidade Lúrio, com ligação para o Google Maps.
- Código de traje e formulário de confirmação por WhatsApp.
- Painel para personalizar fotografias e cores no navegador.

## Personalizações importantes antes de publicar
1. Abra `script.js` e confirme o número em `WEDDING.whatsapp`. O número atualmente configurado foi mantido do projeto anterior: `258842820764`.
2. Confirme se a localização da Sala Magna está correta no mapa. A ligação está configurada para a Universidade Lúrio, em Nampula.
3. Para música de fundo, coloque na pasta principal um ficheiro de áudio a que tenha direito de utilização, com o nome `music.mp3`. A reprodução só começa após uma interação do visitante, devido às regras dos navegadores. A faixa comercial de Whitney Houston não está incluída no ZIP; obtenha-a por uma fonte autorizada e assegure que a sua utilização/publicação é permitida.
4. Para fotografias que apareçam a todos os convidados, coloque os ficheiros na pasta do projeto e defina-os como fundos no CSS, ou use o painel de personalização e depois incorpore os ficheiros no projeto antes de publicar. As imagens carregadas pelo painel ficam apenas no navegador de quem as carregou.

## Publicar na Vercel
- Extraia o ZIP.
- Envie a pasta do projeto para o repositório GitHub ou importe-a na Vercel.
- Não é necessário processo de build: é um site estático.
- O ficheiro `vercel.json` mantém a configuração de publicação estática.
